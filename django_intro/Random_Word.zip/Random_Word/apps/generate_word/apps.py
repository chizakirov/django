from django.apps import AppConfig


class GenerateWordConfig(AppConfig):
    name = 'generate_word'
